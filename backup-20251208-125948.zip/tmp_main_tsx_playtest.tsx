import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Coding_Projects/Nola-Developer-Incubator-main/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b330876"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_reactDom_client from "/@fs/C:/Coding_Projects/Nola-Developer-Incubator-main/node_modules/.vite/deps/react-dom_client.js?v=5b330876"; const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];
import App from "/src/App.tsx";
import "/src/index.css";
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "C:/Coding_Projects/Nola-Developer-Incubator-main/client/src/main.tsx",
  lineNumber: 5,
  columnNumber: 53
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBSW9EO0FBSnBELFNBQVNBLGtCQUFrQjtBQUMzQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU87QUFFUEQsV0FBV0UsU0FBU0MsZUFBZSxNQUFNLENBQUUsRUFBRUMsT0FBTyx1QkFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBSSxDQUFHIiwibmFtZXMiOlsiY3JlYXRlUm9vdCIsIkFwcCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XG5pbXBvcnQgQXBwIGZyb20gXCIuL0FwcFwiO1xuaW1wb3J0IFwiLi9pbmRleC5jc3NcIjtcblxuY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikhKS5yZW5kZXIoPEFwcCAvPik7XG4iXSwiZmlsZSI6IkM6L0NvZGluZ19Qcm9qZWN0cy9Ob2xhLURldmVsb3Blci1JbmN1YmF0b3ItbWFpbi9jbGllbnQvc3JjL21haW4udHN4In0=